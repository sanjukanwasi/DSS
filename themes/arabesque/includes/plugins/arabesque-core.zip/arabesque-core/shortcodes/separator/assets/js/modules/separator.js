(function($) {
    'use strict';

    var separator = {};
    mkdf.modules.separator = separator;

    separator.mkdfInitSeparator = mkdfInitSeparator;


    separator.mkdfOnDocumentReady = mkdfOnDocumentReady;

    $(document).ready(mkdfOnDocumentReady);

    /*
     All functions to be called on $(document).ready() should be in this function
     */
    function mkdfOnDocumentReady() {
        mkdfInitSeparator();
    }

    /*
     **	Horizontal progress bars shortcode
     */
    function mkdfInitSeparator(){
        var separator = $('.mkdf-separator-holder.mkdf-separator-animation-yes');

        if(separator.length){
            separator.each(function() {
                var thisSeparator = $(this),
                    thisSeparatorContent = thisSeparator.find('.mkdf-separator'),
                    width = thisSeparatorContent.data('width');

                thisSeparator.appear(function() {
                    thisSeparatorContent.css('width', '0');
                    thisSeparatorContent.animate({'width': width}, 400);
                });
            });
        }
    }

})(jQuery);