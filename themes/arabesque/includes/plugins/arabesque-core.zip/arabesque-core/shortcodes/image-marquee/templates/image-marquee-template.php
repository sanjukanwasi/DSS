<div class="mkdf-image-marquee-holder">
    <div class="mkdf-image-marquee">
        <?php $element_types = array('original','aux'); ?>
        <?php foreach ($element_types as $element_type) : ?>
            <div class="mkdf-image mkdf-<?php echo esc_attr($element_type); ?>">
                <img src="<?php echo wp_get_attachment_url($image); ?>" alt="<?php echo get_the_title($image) ?>" />
            </div>
        <?php endforeach; ?>
    </div>
</div>