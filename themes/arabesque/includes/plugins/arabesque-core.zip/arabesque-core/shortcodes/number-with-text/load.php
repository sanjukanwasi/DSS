<?php

include_once ARABESQUE_CORE_SHORTCODES_PATH . '/number-with-text/functions.php';
include_once ARABESQUE_CORE_SHORTCODES_PATH . '/number-with-text/number-with-text.php';