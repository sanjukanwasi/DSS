<?php

require_once ARABESQUE_CORE_ABS_PATH . '/core-dashboard/rest/rest.php';