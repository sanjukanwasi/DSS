<?php echo arabesque_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/image', $item_style, $params); ?>

<div class="mkdf-pli-text-holder">
	<div class="mkdf-pli-text-wrapper">
		<div class="mkdf-pli-text">
			<span class="mkdf-pli-icon icon_plus"></span>
		</div>
	</div>
</div>