<?php

if ( ! function_exists( 'arabesque_mikado_portfolio_category_additional_fields' ) ) {
	function arabesque_mikado_portfolio_category_additional_fields() {
		
		$fields = arabesque_mikado_add_taxonomy_fields(
			array(
				'scope' => 'portfolio-category',
				'name'  => 'portfolio_category_options'
			)
		);
		
		arabesque_mikado_add_taxonomy_field(
			array(
				'name'   => 'mkdf_portfolio_category_image_meta',
				'type'   => 'image',
				'label'  => esc_html__( 'Category Image', 'arabesque-core' ),
				'parent' => $fields
			)
		);
	}
	
	add_action( 'arabesque_mikado_action_custom_taxonomy_fields', 'arabesque_mikado_portfolio_category_additional_fields' );
}