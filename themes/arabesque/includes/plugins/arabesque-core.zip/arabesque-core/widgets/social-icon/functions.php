<?php

if ( ! function_exists( 'arabesque_mikado_register_social_icon_widget' ) ) {
	/**
	 * Function that register social icon widget
	 */
	function arabesque_mikado_register_social_icon_widget( $widgets ) {
		$widgets[] = 'ArabesqueMikadoSocialIconWidget';
		
		return $widgets;
	}
	
	add_filter( 'arabesque_mikado_filter_register_widgets', 'arabesque_mikado_register_social_icon_widget' );
}