<?php

include_once ARABESQUE_CORE_ABS_PATH . '/widgets/sticky-sidebar/functions.php';
include_once ARABESQUE_CORE_ABS_PATH . '/widgets/sticky-sidebar/sticky-sidebar.php';