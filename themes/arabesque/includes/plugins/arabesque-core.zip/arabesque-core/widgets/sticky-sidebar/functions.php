<?php

if(!function_exists('arabesque_mikado_register_sticky_sidebar_widget')) {
	/**
	 * Function that register sticky sidebar widget
	 */
	function arabesque_mikado_register_sticky_sidebar_widget($widgets) {
		$widgets[] = 'ArabesqueMikadoStickySidebar';
		
		return $widgets;
	}
	
	add_filter('arabesque_mikado_filter_register_widgets', 'arabesque_mikado_register_sticky_sidebar_widget');
}