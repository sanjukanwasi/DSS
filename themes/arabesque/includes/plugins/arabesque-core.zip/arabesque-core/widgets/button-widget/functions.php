<?php

if ( ! function_exists( 'arabesque_mikado_register_button_widget' ) ) {
	/**
	 * Function that register button widget
	 */
	function arabesque_mikado_register_button_widget( $widgets ) {
		$widgets[] = 'ArabesqueMikadoButtonWidget';
		
		return $widgets;
	}
	
	add_filter( 'arabesque_mikado_filter_register_widgets', 'arabesque_mikado_register_button_widget' );
}