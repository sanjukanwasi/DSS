<?php

include_once ARABESQUE_CORE_ABS_PATH . '/widgets/image-gallery/functions.php';
include_once ARABESQUE_CORE_ABS_PATH . '/widgets/image-gallery/image-gallery.php';