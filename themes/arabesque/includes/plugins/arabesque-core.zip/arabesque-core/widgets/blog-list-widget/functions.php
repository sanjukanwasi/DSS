<?php

if ( ! function_exists( 'arabesque_mikado_register_blog_list_widget' ) ) {
	/**
	 * Function that register blog list widget
	 */
	function arabesque_mikado_register_blog_list_widget( $widgets ) {
		$widgets[] = 'ArabesqueMikadoBlogListWidget';
		
		return $widgets;
	}
	
	add_filter( 'arabesque_mikado_filter_register_widgets', 'arabesque_mikado_register_blog_list_widget' );
}