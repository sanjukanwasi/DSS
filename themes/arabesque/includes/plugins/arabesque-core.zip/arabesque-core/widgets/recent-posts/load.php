<?php

include_once ARABESQUE_CORE_ABS_PATH . '/widgets/recent-posts/functions.php';
include_once ARABESQUE_CORE_ABS_PATH . '/widgets/recent-posts/recent-posts.php';
