<?php

if ( ! function_exists( 'arabesque_mikado_register_custom_font_widget' ) ) {
	/**
	 * Function that register custom font widget
	 */
	function arabesque_mikado_register_custom_font_widget( $widgets ) {
		$widgets[] = 'ArabesqueMikadoCustomFontWidget';
		
		return $widgets;
	}
	
	add_filter( 'arabesque_mikado_filter_register_widgets', 'arabesque_mikado_register_custom_font_widget' );
}