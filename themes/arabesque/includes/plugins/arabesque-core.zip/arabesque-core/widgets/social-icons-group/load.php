<?php

include_once ARABESQUE_CORE_ABS_PATH . '/widgets/social-icons-group/functions.php';
include_once ARABESQUE_CORE_ABS_PATH . '/widgets/social-icons-group/social-icons-group.php';