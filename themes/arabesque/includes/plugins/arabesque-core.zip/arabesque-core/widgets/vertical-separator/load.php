<?php

include_once ARABESQUE_CORE_ABS_PATH . '/widgets/vertical-separator/functions.php';
include_once ARABESQUE_CORE_ABS_PATH . '/widgets/vertical-separator/vertical-separator.php';